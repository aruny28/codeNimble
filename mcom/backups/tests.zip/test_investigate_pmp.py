import json
import os
import time
import unittest
from appium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class TestKohlsWeb(unittest.TestCase):

    def setUp(self):
        self.driver = webdriver.Remote(
            command_executor = os.getenv('COMMAND_EXECUTOR'),
            desired_capabilities = json.loads(os.getenv('DESIRED_CAPABILITIES'))
        )
        self.driver.implicitly_wait(10)

    def test_investigate_pmp(self):
        time.sleep(2)
        print 'Scenario.begin load_products'
        self.driver.get('https://ma-dev2.kohlsecommerce.com/search.jsp?search=shirts&isFromSearch=true&personalizedPMP=true')
        self.driver.add_cookie({'name': 'kohls_debug', 'value': 'true'})
        time.sleep(0.5)
        # Make sure filters have been applied and page has loaded
        #self.driver.find_element_by_class_name('GoogleActiveViewElement').find_elements_by_class_name('dvm-fluid-ad')
        EC.presence_of_element_located((By.CLASS_NAME, "dvm-fluid-ad"))
        #self.driver.find_element_by_class_name('dvm-fluid-ad')
        print 'Scenario.end load_products'
	
    	time.sleep(10)
        self.driver.quit()
