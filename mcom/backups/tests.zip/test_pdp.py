import json
import os
import time
import unittest
from appium import webdriver

class TestKohlsWeb(unittest.TestCase):

    def setUp(self):
        self.driver = webdriver.Remote(
            command_executor = os.getenv('COMMAND_EXECUTOR'),
            desired_capabilities = json.loads(os.getenv('DESIRED_CAPABILITIES'))
        )
        self.driver.implicitly_wait(10)

    def test_pdp(self):
        time.sleep(2)
        print 'Scenario.begin load_product_details'
        self.driver.get('https://mcom-qa2.kohlsecommerce.com/product/prd-1845910/disney-frozen-elsa-woven-front-babydoll-top-by-jumping-beans-girls-4-7.jsp?prdPV=1&userPFM=disney%20shirts&diestoreid=217&selectShip=true&relVersion=123')
        self.driver.add_cookie({'name': 'kohls_debug', 'value': 'true'})
        time.sleep(0.5)
        # Make sure product page has loaded
        add_to_cart = self.driver.find_element_by_id('add-to-bag-btn')
        print 'Scenario.end load_product_details'

    	time.sleep(10)
        self.driver.quit()
